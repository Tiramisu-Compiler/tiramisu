TIRAMISU_ROOT=/Users/b/Documents/src/MIT/tiramisu/
BENCHMARK_ROOT=${TIRAMISU_ROOT}/benchmarks/linear_algebra/blas/level3/framework-comparison/
LLVM_PREFIX=${TIRAMISU_ROOT}/3rdParty/llvm/prefix/
CC=${LLVM_PREFIX}/bin/clang
OPENMP_LIB=iomp5
OPENMP_DIR=/usr/local/Cellar/libiomp/20150701/
OPENBLAS_DIR=/Volumes/ALL/extra/OpenBLAS/
OpenBLAS_FLAGS="-lcblas"

PPCG=${BENCHMARK_ROOT}/software/ppcg/ppcg
HALIDE_PREFIX=${TIRAMISU_ROOT}/3rdParty/Halide/
