#!/bin/bash

find . -name "*verify-rand"; find . -name "*verify-rand" -exec {} 1000 1000 1000 20 20 100 \;

